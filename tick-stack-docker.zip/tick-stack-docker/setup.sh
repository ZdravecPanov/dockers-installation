#!/bin/bash

echo "🔧 Starting TICK Stack + Grafana Setup..."

# Step 1: Load .env file if it exists
if [ -f .env ]; then
  echo "✅ .env file found. Loading..."
  export $(grep -v '^#' .env | xargs)
else
  echo "⚠️  .env file not found. Using default values."
fi

# Step 2: Ensure required directories exist
mkdir -p telegraf kapacitor grafana influxdb

# Step 3: Start Docker containers
echo "🚀 Launching Docker Compose stack..."
docker-compose up -d

# Step 4: Provide useful info
echo ""
echo "🎉 All services are starting!"
echo "🌐 Grafana:     http://localhost:3000 (admin/admin)"
echo "📈 InfluxDB:    http://localhost:8086"
echo "🔔 Kapacitor:   http://localhost:9092"
echo "📡 Telegraf is collecting metrics."
