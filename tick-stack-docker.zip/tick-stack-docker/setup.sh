#!/bin/bash

echo "🔧 Starting TICK Stack + Grafana Setup..."

# Function to check command existence
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Step 1: Install Docker if not installed
if command_exists docker; then
  echo "✅ Docker is already installed."
else
  echo "🐳 Docker not found. Installing..."
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl gnupg lsb-release

  sudo mkdir -p /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

  echo     "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu     $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

  sudo apt-get update
  sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

  echo "✅ Docker installed successfully."
fi

# Step 2: Ensure Docker Compose is available
if docker compose version >/dev/null 2>&1; then
  echo "✅ Docker Compose plugin is available."
else
  echo "❌ Docker Compose plugin not found. Please install it manually."
  exit 1
fi

# Step 3: Load .env file if it exists
if [ -f .env ]; then
  echo "✅ .env file found. Loading..."
  export $(grep -v '^#' .env | xargs)
else
  echo "⚠️  .env file not found. Using default values."
fi

# Step 4: Ensure required directories exist
mkdir -p telegraf kapacitor grafana influxdb

# Step 5: Start Docker containers
echo "🚀 Launching Docker Compose stack..."
docker compose up -d

# Step 6: Provide useful info
echo ""
echo "🎉 All services are starting!"
echo "🌐 Grafana:     http://localhost:3000 (admin/admin)"
echo "📈 InfluxDB:    http://localhost:8086"
echo "🔔 Kapacitor:   http://localhost:9092"
echo "📡 Telegraf is collecting metrics."
